#ifndef _HEADFILE_H
#define _HEADFILE_H

#include "config.h"

#include "led.h"
#include "smg.h"
#include "timer.h"
#include "key.h"

#include "ds1302.h"
#include "onewire.h"

#endif