#ifndef __ONEWIRE_H
#define __ONEWIRE_H

#include "config.h"

//sbit DQ = P1^4;  

unsigned char rd_temperature(void);  


uint temp_read();

#endif
