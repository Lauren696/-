#ifndef _KEY_H
#define _KEY_H

#include "config.h"

void key_scanf();

#endif