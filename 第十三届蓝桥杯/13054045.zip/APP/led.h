#ifndef _LED_H
#define _LED_H

#include "config.h"

void all_init();
void led_scan();
void led_light(uchar a);
void led_unlight(uchar a);


#endif