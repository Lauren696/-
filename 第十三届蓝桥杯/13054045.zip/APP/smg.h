#ifndef _SMG_H
#define _SMG_H

#include "config.h"

void smg_scan(uchar p,n);
void smg_d(uchar d0,d1,d2,d3,d4,d5,d6,d7);

#endif