#ifndef _TIMER_H
#define _TIMER_H

#include "config.h"
#include "led.h"
#include "smg.h"


void timer1_init(void);		//1����@12.000MHz
void timer0_init(void);		//5����@12.000MHz

#endif